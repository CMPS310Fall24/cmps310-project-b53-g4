package milestone2;

public class InsuranceCompany {
	
    public void acknowledgeReport(AccidentReport report) {
        System.out.println("Acknowledgement: Accident report for VIN " 
    + report.getOffendingVehicle().getVin() + " has been received.");
    }
    
    public void storeAccidentReport(AccidentReport report) {
        System.out.println("Accident report stored for VIN " + 
    report.getOffendingVehicle().getVin());
    }


}
