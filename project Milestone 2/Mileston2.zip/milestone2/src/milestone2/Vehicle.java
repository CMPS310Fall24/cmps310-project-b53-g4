package milestone2;

public class Vehicle {
	private String vin;
    private String ownerName;
    private String insurancePolicy;
	public Vehicle(String vin, String ownerName, String insurancePolicy) {
		super();
		this.vin = vin;
		this.ownerName = ownerName;
		this.insurancePolicy = insurancePolicy;
	}
	public String getVin() {
		return vin;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getInsurancePolicy() {
		return insurancePolicy;
	}
	public void setInsurancePolicy(String insurancePolicy) {
		this.insurancePolicy = insurancePolicy;
	}


}
