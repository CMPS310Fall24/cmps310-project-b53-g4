package milestone2;

public class AccidentReport {
	private Vehicle offendingVehicle;
    private Vehicle victimVehicle;
    private String accidentDetails;
    private boolean confirmed;

    public void confirm() {
        this.confirmed = true;
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public Vehicle getOffendingVehicle() {
        return offendingVehicle;
    }

    public Vehicle getVictimVehicle() {
        return victimVehicle;
    }

    public String getAccidentDetails() {
        return accidentDetails;
    }

	public AccidentReport(Vehicle offendingVehicle, Vehicle victimVehicle, String accidentDetails, boolean confirmed) {
		super();
		this.offendingVehicle = offendingVehicle;
		this.victimVehicle = victimVehicle;
		this.accidentDetails = accidentDetails;
		this.confirmed = confirmed;
	}

	public AccidentReport(Vehicle offendingVehicle, Vehicle victimVehicle, String accidentDetails) {
		super();
		this.offendingVehicle = offendingVehicle;
		this.victimVehicle = victimVehicle;
		this.accidentDetails = accidentDetails;
	}

    
    
    
}
