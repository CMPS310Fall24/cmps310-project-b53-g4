package milestone2;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        AccidentManagementSystem system = new AccidentManagementSystem();
        
        // Register vehicles in the system
        system.registerVehicle("VIN12345", "John Doe", "Policy123");
        system.registerVehicle("VIN67890", "Jane Smith", "Policy456");

        // Manage accident
        system.manageAccident("VIN12345", "VIN67890", "Rear-end collision at intersection.");
    }

	}
