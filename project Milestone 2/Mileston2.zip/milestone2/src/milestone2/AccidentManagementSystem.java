package milestone2;

import java.util.HashMap;
import java.util.Map;

public class AccidentManagementSystem {
    private Map<String, Vehicle> vehiclesDatabase = new HashMap<>();
    private InsuranceCompany insuranceCompany = new InsuranceCompany();

    public void registerVehicle(String vin, String ownerName, String insurancePolicy) {
        vehiclesDatabase.put(vin, new Vehicle(vin, ownerName, insurancePolicy));
    }

    public AccidentReport manageAccident(String vin1, String vin2, String accidentDetails) {
        Vehicle vehicle1 = vehiclesDatabase.get(vin1);
        Vehicle vehicle2 = vehiclesDatabase.get(vin2);

        if (vehicle1 == null || vehicle2 == null) {
            System.out.println("One or both VINs not found.");
            return null;
        }

        AccidentReport report = new AccidentReport(vehicle1, vehicle2, accidentDetails);
        
        // Set the owner’s vehicle as the offending vehicle and the other as the victim
        System.out.println("Setting " + vin1 + " as offending vehicle and " + vin2 + " as victim vehicle.");
        
        // Confirm the accident details
        report.confirm();
        System.out.println("Accident details confirmed.");
        
        // Send report to the insurance company
        insuranceCompany.acknowledgeReport(report);
        insuranceCompany.storeAccidentReport(report);
        
        return report;
    }


}
